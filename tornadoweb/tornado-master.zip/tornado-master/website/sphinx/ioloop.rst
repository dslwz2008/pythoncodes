``tornado.ioloop`` --- Main event loop
======================================

.. automodule:: tornado.ioloop
   :members:
