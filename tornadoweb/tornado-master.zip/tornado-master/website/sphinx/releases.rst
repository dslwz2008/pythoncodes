Release notes
=============

.. toctree::
   :maxdepth: 2

   releases/v1.2.1
   releases/v1.2.0
   releases/v1.1.1
   releases/v1.1.0
   releases/v1.0.1
   releases/v1.0.0
