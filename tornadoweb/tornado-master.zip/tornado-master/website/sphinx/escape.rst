``tornado.escape`` --- Escaping and string manipulation
=======================================================

.. automodule:: tornado.escape
   :members:
