``tornado.iostream`` --- Convenient wrappers for non-blocking sockets
=====================================================================

.. automodule:: tornado.iostream
   :members:
