``tornado.auth`` --- Third-party login with OpenID and OAuth
============================================================

.. automodule:: tornado.auth
   :members:
